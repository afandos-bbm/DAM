package me.alejandrofan2.dam.serviciosprocesos;

public class Logger {

}
