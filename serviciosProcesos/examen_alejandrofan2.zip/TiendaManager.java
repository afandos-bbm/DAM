package me.alejandrofan2.dam.serviciosprocesos;

import static java.lang.String.format;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Semaphore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TiendaManager {

    private static final Logger log = LoggerFactory.getLogger("Tienda Manager");
    private Semaphore semaphore = new Semaphore(1);
    private Semaphore waiter = new Semaphore(0);
    private ArrayList<String> listaPedidios = new ArrayList<String>();
    private Random random = new Random();
    private int nPedidos = 0;

    void trabajar(String name) {
        try {
            log.info("Esperando pedido...");
            waiter.acquire();
            semaphore.acquire();
            
            nPedidos++;
            String nombreCliente = listaPedidios.get(0);
            listaPedidios.remove(0);
            log.info(format("Ha iniciado un nuevo pedido de %s", nombreCliente));
            
            semaphore.release();

            Thread.sleep((random.nextInt(5) + 10) * 1000L);
            log.info(format("Ha finalizado el pedido nº%d de %s", nPedidos, nombreCliente));
        } catch (Exception e) {
            log.error(format(
                    "Ha habido un error durante la ejecucion de el codigo del trabajadorT en el manager. Error: %s",
                    e.getLocalizedMessage()));
        }
    }

    void pedir(String name) {
        try {
            log.info("Ha entrado a la tienda.");
            Thread.sleep((random.nextInt(120) + 1) * 1000L);
            semaphore.acquire();
            
            listaPedidios.add(name);
            log.info(format("Nuevo pedido de %s - Pedidios pendientes %d", name, listaPedidios.size()));
            waiter.release();

            semaphore.release();
        } catch (Exception e) {
            log.error(
                    format("Ha habido un error durante la ejecucion de el codigo del ClienteT en el manager. Error: %s",
                            e.getLocalizedMessage()));
        }
    }
}