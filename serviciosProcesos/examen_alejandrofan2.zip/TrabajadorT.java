package me.alejandrofan2.dam.serviciosprocesos;

import static java.lang.String.format;

public class TrabajadorT extends Thread {

    private TiendaManager manager;

    public TrabajadorT(String name, TiendaManager manager) {
        super(name);
        this.manager = manager;
    }

    @Override
    public void run() {
        while (true) {
            manager.trabajar(super.getName());
        }
    }
}