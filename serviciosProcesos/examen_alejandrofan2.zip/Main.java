package me.alejandrofan2.dam.serviciosprocesos;

import java.lang.Thread;

/**
 * Hello world!
 *
 */
public class Main {
    public static void main(String[] args) {
        TiendaManager manager = new TiendaManager();
        for (int i = 0; i < 2; i++)
            new TrabajadorT("Trabajador " + i, manager).start();

        for (int i = 0; i < 5; i++)
            new ClienteT("Cliente " + i, manager).start();
    }

}
